/**
 *
 * PracticePage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose, bindActionCreators } from 'redux';

// import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectPracticePage from './selectors';
import reducer from './reducer';
// import saga from './saga';

import Actions from './actions';
import { selectors as PracticePageSelectors } from './selectors';


/* eslint-disable react/prefer-stateless-function */
export class PracticePage extends React.PureComponent {

    handleOnclick = () => {
      const { changeValue } = this.props;
      changeValue();
    }

  render() {
    const { testValue } = this.props;
    console.log(testValue)
    return (
      <div>
        PracticePage
        {`value: ${testValue}`}
        <br />
        <input 
          type='button'
          value='click to change'
          onClick={this.handleOnclick}
          />
      </div>
    );
  }
}

PracticePage.propTypes = {
  // dispatch: PropTypes.func.isRequired,
  testValue: PropTypes.bool,
};

const mapStateToProps = createStructuredSelector({
  practicePage: makeSelectPracticePage(),
  testValue: PracticePageSelectors.selectChangeValue(),
});

function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators({
        ...Actions.Creators,
    },dispatch),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'practicePage', reducer });
// const withSaga = injectSaga({ key: 'practicePage', saga });

export default compose(
  withReducer,
  // withSaga,
  withConnect,
)(PracticePage);
