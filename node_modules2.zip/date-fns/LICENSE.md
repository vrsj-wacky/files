# License

date-fns is licensed under the [MIT license](http://kossnocorp.mit-license.org).
Read more about MIT at [TLDRLegal](https://tldrlegal.com/license/mit-license).
