import { fromJS } from 'immutable';
import demoPageReducer from '../reducer';

describe('demoPageReducer', () => {
  it('returns the initial state', () => {
    expect(demoPageReducer(undefined, {})).toEqual(fromJS({}));
  });
});
