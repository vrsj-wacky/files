// import { fromJS } from 'immutable';
// import { selectDemoPageDomain } from '../selectors';

describe('selectDemoPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
