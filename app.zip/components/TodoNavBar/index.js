/**
 *
 * TodoNavBar
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose, bindActionCreators } from 'redux';
import injectReducer from 'utils/injectReducer';
import reducer from '../TodoDrawer/reducer';
import makeSelectTodoDrawer from './../TodoDrawer/selectors';
import Actions from './../TodoDrawer/actions';
import { selectors as TodoDrawerSelectors } from './../TodoDrawer/selectors';

const styles = {
  root: {
    flexGrow: 1,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
};


/* eslint-disable react/prefer-stateless-function */
class TodoNavBar extends React.PureComponent {
  drawerChangeHandler = () => {
    const { changeDrawer } = this.props;
    changeDrawer();
  }
  render() {

    const { classes } = this.props;

    return (
      <div className={classes.root}>
      <AppBar position="static">
        <Toolbar>
          <IconButton 
            className={classes.menuButton} 
            color="inherit" 
            aria-label="Menu"
            onClick={this.drawerChangeHandler}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" color="inherit" className={classes.grow}>
            Wacky's Todo App
          </Typography>
        </Toolbar>
      </AppBar>
    </div>
    );
  }
}

TodoNavBar.propTypes = {
  classes: PropTypes.object.isRequired,
  isDrawerOpen: PropTypes.bool,
};

const mapStateToProps = createStructuredSelector({
  todoDrawer: makeSelectTodoDrawer(),
  isDrawerOpen: TodoDrawerSelectors.selectChangeDrawer(),
});

function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators({
      ...Actions.Creators,
    }, dispatch),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps
);

const withReducer = injectReducer({ key: 'todoDrawer', reducer });

export default compose(
  withReducer,
  withConnect,
  withStyles(styles),
)(TodoNavBar);
