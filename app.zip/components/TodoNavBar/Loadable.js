/**
 *
 * Asynchronously loads the component for TodoNavBar
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
