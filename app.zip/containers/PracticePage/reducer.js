/*
 *
 * PracticePage reducer
 *
 */

import { fromJS } from 'immutable';
import { createReducer } from 'reduxsauce';
import Actions from './actions';

const INITIAL_STATE = fromJS({
  testValue: false,
});

export const doChangeValue123 = (state) => {
  const ret = state.merge({
    testValue: !state.toJS().testValue
  })

  return ret;
}

const Types = Actions.Types;

export const reducer = createReducer(INITIAL_STATE, {
  [Types.CHANGE_VALUE] : doChangeValue123,
});

export default reducer;