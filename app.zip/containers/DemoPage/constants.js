/*
 *
 * DemoPage constants
 *
 */

export const DEFAULT_ACTION = 'app/DemoPage/DEFAULT_ACTION';
