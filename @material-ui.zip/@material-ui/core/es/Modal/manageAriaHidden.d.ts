export function ariaHidden(node: Node, show: boolean): never;
export function ariaHiddenSiblings(
  container: Element,
  mountNode: Node,
  currentNode: Node,
  show: boolean,
): never;
