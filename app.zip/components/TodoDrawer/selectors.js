import { createSelector } from "reselect";

const selectTodoDrawerDomain = state =>
    state.get('todoDrawer');

const makeSelectTodoDrawer = () =>
    createSelector(selectTodoDrawerDomain, substate => substate.toJS());

export default makeSelectTodoDrawer;
export { selectTodoDrawerDomain };

export const selectors = {
    selectChangeDrawer: () => createSelector(selectTodoDrawerDomain, (windowState) => windowState.toJS().drawerValue),
    selectChangeTab: () => createSelector(selectTodoDrawerDomain, (windowState) => windowState.toJS().tabInfo)
}