// import { fromJS } from 'immutable';
// import { selectPracticePageDomain } from '../selectors';

describe('selectPracticePageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
