/**
 *
 * DemoPage
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import makeSelectDemoPage from './selectors';
import reducer from './reducer';
import saga from './saga';
import DemoDate from '../../components/DemoDate';

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing.unit * 2,
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
});


/* eslint-disable react/prefer-stateless-function */
export class DemoPage extends React.PureComponent {
  render() {

    const { classes } = this.props;

    return (
      <div  className={classes.root}>
        <Grid container spacing={24} >
          <Grid item xs={6}>
            <Paper className={classes.paper}>
              <DemoDate />
            </Paper>
          </Grid>
        </Grid>
      </div>
    );
  }
}

DemoPage.propTypes = {
  dispatch: PropTypes.func.isRequired,
  classes: PropTypes.object.isRequired,
};

const mapStateToProps = createStructuredSelector({
  demoPage: makeSelectDemoPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'demoPage', reducer });
const withSaga = injectSaga({ key: 'demoPage', saga });

export default compose(
  withStyles(styles),
  withReducer,
  withSaga,
  withConnect,
)(DemoPage);
