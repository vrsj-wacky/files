import Download from './components/Download';
import Link from './components/Link';

export const CSVDownload = Download;
export const CSVLink = Link;
