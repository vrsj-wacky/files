/*
 *
 * TodoDrawer reducer
 *
 */

import { fromJS } from 'immutable';
import { createReducer } from 'reduxsauce';
import Actions from './actions';

const INITIAL_STATE = fromJS({
    drawerValue: false,
    tabInfo: {
        tabIndex: 0,
        tabName: 'Todo',
    },
})

export const doChangeDrawerValue = (state) => {
    const ret = state.merge({
        drawerValue: !state.toJS().drawerValue
    });
    return ret;
}

export const doChangeTab = (state, { index, name }) => {
    const ret = state.merge({
        tabInfo: {
            tabIndex: index,
            tabName: name
        }
    });
    return ret;
}
const Types = Actions.Types;

export const reducer = createReducer(INITIAL_STATE, {
    [Types.CHANGE_DRAWER]: doChangeDrawerValue,
    [Types.CHANGE_TAB]: doChangeTab,
})

export default reducer;