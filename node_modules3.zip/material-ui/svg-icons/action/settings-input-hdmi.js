'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _pure = require('recompose/pure');

var _pure2 = _interopRequireDefault(_pure);

var _SvgIcon = require('../../SvgIcon');

var _SvgIcon2 = _interopRequireDefault(_SvgIcon);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ActionSettingsInputHdmi = function ActionSettingsInputHdmi(props) {
  return _react2.default.createElement(
    _SvgIcon2.default,
    props,
    _react2.default.createElement('path', { d: 'M18 7V4c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2v3H5v6l3 6v3h8v-3l3-6V7h-1zM8 4h8v3h-2V5h-1v2h-2V5h-1v2H8V4z' })
  );
};
ActionSettingsInputHdmi = (0, _pure2.default)(ActionSettingsInputHdmi);
ActionSettingsInputHdmi.displayName = 'ActionSettingsInputHdmi';
ActionSettingsInputHdmi.muiName = 'SvgIcon';

exports.default = ActionSettingsInputHdmi;