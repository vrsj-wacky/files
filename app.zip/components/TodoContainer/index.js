/**
 *
 * TodoContainer
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import DeleteIcon from '@material-ui/icons/Delete';
import {
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
} from '@material-ui/core';
// import styled from 'styled-components';

import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose, bindActionCreators } from 'redux';
import injectReducer from 'utils/injectReducer';
import reducer from '../TodoDrawer/reducer';
import { reducer as TodoContainerReducer } from './reducer';
import makeSelectTodoDrawer from './../TodoDrawer/selectors';
import Actions from './../TodoDrawer/actions';
import { selectors as TodoDrawerSelectors } from './../TodoDrawer/selectors';
import { withStyles } from '@material-ui/core/styles';

const styles = {
  root: {
    margin: 20,
    padding: 20,
    maxWidth: 400,
    margin: '0 auto', 
    marginTop: '32px'
  },
  form: {
    display: 'flex',
    alignItems: 'baseline',
    justifyContent: 'space-evenly',
  },
};

/* eslint-disable react/prefer-stateless-function */
class TodoContainer extends React.PureComponent {
  clickAddHandler = event => {
    event.preventDefault();
  };

  render() {
    const { tabInfo } = this.props;
    const { classes } = this.props

    return (
      <div>
        {
          tabInfo.tabIndex === 0 && 
          <div>
            <Paper className={classes.root}>
              <Typography variant="display1" align="center" gutterBottom>
                {tabInfo.tabName}
              </Typography>
              <form onSubmit={this.clickAddHandler} className={classes.form}>
                <TextField
                  name="title"
                  label="Add new task ..."
                  //value={title}
                  //onChange={this.handleChange}
                  margin="normal"
                />
                <Button type="submit" color="primary" variant="contained">
                  Add
                </Button>
              </form>
              <List>
                {/* {exercises.map(({ id, title }) => ( */}
                <ListItem>
                  <ListItemText primary={'Hello'} />
                  <ListItemSecondaryAction>
                    <IconButton
                      color="primary"
                      //onClick={() => this.handleDelete(id)}
                    >
                    <DeleteIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              </List>
            </Paper>
          </div>
        }
        {
          tabInfo.tabIndex === 1 &&
          <div>
            <Paper className={classes.root}>
              <Typography variant="display1" align="center" gutterBottom>
                {tabInfo.tabName}
              </Typography>
            </Paper>
          </div>
        }
        {
          tabInfo.tabIndex === 2 && 
          <div>
            <Paper className={classes.root}>
              <Typography variant="display1" align="center" gutterBottom>
                {tabInfo.tabName}
              </Typography>
            </Paper>
          </div>
        }
      </div>
    );
  }
}

TodoContainer.propTypes = {
  tabValue: PropTypes.any,
};

const mapStateToProps = createStructuredSelector({
  todoDrawer: makeSelectTodoDrawer(),
  tabInfo: TodoDrawerSelectors.selectChangeTab(),
});

function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators(
      {
        ...Actions.Creators,
      },
      dispatch,
    ),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'todoDrawer', reducer });

export default compose(
  withStyles(styles),
  withReducer,
  withConnect,
)(TodoContainer);
