/*
 * PracticePage Messages
 *
 * This contains all the text for the PracticePage container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.PracticePage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the PracticePage container!',
  },
});
