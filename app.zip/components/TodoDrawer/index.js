/**
 *
 * TodoDrawer
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import WarningIcon from '@material-ui/icons/Warning';
import ArchiveIcon from '@material-ui/icons/Archive';
import ListIcon from '@material-ui/icons/List';

import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose, bindActionCreators } from 'redux';
import injectReducer from 'utils/injectReducer';
import reducer from './reducer';
import makeSelectTodoDrawer from './selectors';
import Actions from './actions';
import { selectors as TodoDrawerSelectors } from './selectors';


const styles = {
  list: {
    width: 250,
  },
  fullList: {
    width: 'auto',
  },
};

const tabs = ['Todo', 'Archive', 'Secret'];

/* eslint-disable react/prefer-stateless-function */
class TodoDrawer extends React.PureComponent {

  toggleDrawerHandler = () => {
    const { changeDrawer } = this.props;
    changeDrawer();
  }

  changeTabHandler = (index, name) => {
    const { changeTab } = this.props;
    changeTab(index, name);
  }


  render() {

    const { classes, isDrawerOpen } = this.props;

    const sideList = (
      <div className={classes.list}>
        <List>
          {tabs.map((text, index) => (
            <ListItem button key={text} onClick={() => this.changeTabHandler(index, tabs[index])}>
              <ListItemIcon>{index === 0 ? <ListIcon /> : index === 1 ? <ArchiveIcon /> : <WarningIcon />}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItem>
          ))}
        </List>
      </div>
    );


    return (
      <div>
        <Drawer open={isDrawerOpen} onClose={this.toggleDrawerHandler}>
          {sideList}
        </Drawer>
      </div>
    );
  }
}

TodoDrawer.propTypes = {
  classes: PropTypes.object.isRequired,
  isDrawerOpen: PropTypes.bool,
};

const mapStateToProps = createStructuredSelector({
  todoDrawer: makeSelectTodoDrawer(),
  isDrawerOpen: TodoDrawerSelectors.selectChangeDrawer(),
});

function mapDispatchToProps(dispatch) {
  return {
    ...bindActionCreators({
      ...Actions.Creators,
    }, dispatch),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps
);

const withReducer = injectReducer({ key: 'todoDrawer', reducer });

export default 
compose(
  withReducer,
  withConnect,
  withStyles(styles),
)(TodoDrawer);
