import { createSelector } from "reselect";

const selectTodoContainerDomain = state =>
    state.get('todoContainer');

const makeSelectTodoContainer = () =>
    createSelector(selectTodoContainerDomain, substate => substate.toJS());

export default makeSelectTodoContainer;
export { selectTodoContainerDomain };

export const selectors = {
    selectClearInput: () => createSelector(selectTodoContainerDomain, (windowState) => windowState.toJS().inputValue),
    selectAddTask: () => createSelector(selectTodoContainerDomain, (windowState) => windowState.toJS().tasks)
}