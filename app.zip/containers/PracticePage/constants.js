/*
 *
 * PracticePage constants
 *
 */

export const DEFAULT_ACTION = 'app/PracticePage/DEFAULT_ACTION';
