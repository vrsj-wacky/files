import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the demoPage state domain
 */

const selectDemoPageDomain = state => state.get('demoPage', initialState);

/**
 * Other specific selectors
 */

/**
 * Default selector used by DemoPage
 */

const makeSelectDemoPage = () =>
  createSelector(selectDemoPageDomain, substate => substate.toJS());

export default makeSelectDemoPage;
export { selectDemoPageDomain };
