export { default } from './CardMedia';
export * from './CardMedia';
