/**
 *
 * DemoDate
 *
 */

import React from 'react';
import { DateFormatInput } from 'material-ui-next-pickers';

// import PropTypes from 'prop-types';
// import styled from 'styled-components';

/* eslint-disable react/prefer-stateless-function */
class DemoDate extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      date: ''
    }
  }

  dateChangeHandler = (date) => {
    this.setState({date})
  }

  render() {

    const { date } = this.state;

    return (
      <div>
        <DateFormatInput 
          name='date-input'
          value={date}
          onChange={this.dateChangeHandler}
          label='Start Date'
          max={new Date()}
          dialog={true}
        />
      </div>
    );
  }
}

DemoDate.propTypes = {};

export default DemoDate;
