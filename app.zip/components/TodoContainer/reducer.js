/*
 *
 * Todo Container reducer
 *
 */

import { fromJS } from 'immutable';
import { createReducer } from 'reduxsauce';
import Actions from './actions';

const INITIAL_STATE = fromJS({
    inputValue: '',
    tasks: [
        {
            id: '',
            task: '',
        }
    ]
})

export const doClearInput = (state) => {
    const ret = state.merge({
        inputValue: ''
    });
    return ret;
}

export const doAddTask = (state, { id, task }) => {
    const ret = state.merge({
        tasks: {
            id: id,
            task: task
        }
    });
    return ret;
}
const Types = Actions.Types;

export const reducer = createReducer(INITIAL_STATE, {
    [Types.CLEAR_INPUT]: doClearInput,
    [Types.ADD_TASK]: doAddTask,
})

export default reducer;