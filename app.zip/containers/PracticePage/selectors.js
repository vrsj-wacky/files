import { createSelector } from 'reselect';


/**
 * Direct selector to the practicePage state domain
 */

const selectPracticePageDomain = state =>
  state.get('practicePage');

/**
 * Other specific selectors
 */

/**
 * Default selector used by PracticePage
 */

const makeSelectPracticePage = () =>
  createSelector(selectPracticePageDomain, substate => substate.toJS());

export default makeSelectPracticePage;
export { selectPracticePageDomain };

export const selectors = {
  selectChangeValue: () => createSelector(selectPracticePageDomain, (windowState) => windowState.toJS().testValue)
}
