/*
 * DemoCsv Messages
 *
 * This contains all the text for the DemoCsv component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.DemoCsv';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the DemoCsv component!',
  },
});
