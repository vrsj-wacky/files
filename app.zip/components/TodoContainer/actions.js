/*
 *
 * Todo Container actions
 *
 */

import { createActions } from 'reduxsauce';

const { Types, Creators } = createActions({
    clearInput: null,
    addTask: ['id', 'task'],
})

const Actions = {
    Types,
    Creators
}

export default Actions;
