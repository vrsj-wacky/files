/*
 * TodoContainer Messages
 *
 * This contains all the text for the TodoContainer component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.TodoContainer';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the TodoContainer component!',
  },
});
