☣️ **Warning**: This branch is used to generate documentation from v1 branch.
Don't merge or delete it.

See [master](https://github.com/date-fns/date-fns) for the actual date-fns version.

See [v1](https://github.com/date-fns/date-fns/tree/v1) branch for the latest v1 version.
