import { fromJS } from 'immutable';
import practicePageReducer from '../reducer';

describe('practicePageReducer', () => {
  it('returns the initial state', () => {
    expect(practicePageReducer(undefined, {})).toEqual(fromJS({}));
  });
});
