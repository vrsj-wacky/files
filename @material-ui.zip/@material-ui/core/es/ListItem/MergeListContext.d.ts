import * as React from 'react';

export interface MergeWithListContextProps {
  dense?: boolean;
}

declare const MergeWithListContext: React.ComponentType<MergeWithListContextProps>;

export default MergeWithListContext;
