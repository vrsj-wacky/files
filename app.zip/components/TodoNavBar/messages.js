/*
 * TodoNavBar Messages
 *
 * This contains all the text for the TodoNavBar component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.TodoNavBar';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the TodoNavBar component!',
  },
});
