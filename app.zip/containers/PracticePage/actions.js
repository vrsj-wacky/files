/*
 *
 * PracticePage actions
 *
 */


import { createActions } from 'reduxsauce';

const { Types, Creators } = createActions({
  changeValue: null,
})

const Actions = {
  Types,
  Creators
};

export default Actions;