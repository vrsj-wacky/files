/**
 *
 * Asynchronously loads the component for DemoDate
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
